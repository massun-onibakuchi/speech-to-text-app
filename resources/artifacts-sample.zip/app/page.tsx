import { AppShell } from "@/components/stt/app-shell"

export default function Page() {
  return <AppShell />
}
