"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Plus, Star, StarOff, Pencil, Trash2, Check, X, Zap } from "lucide-react"

interface TransformationProfile {
  id: string
  title: string
  provider: string
  model: string
  systemPrompt: string
  userPrompt: string
  shortcutContext: string
}

const initialProfiles: TransformationProfile[] = [
  {
    id: "default",
    title: "Default Rewrite",
    provider: "google",
    model: "gemini-1.5-flash-8b",
    systemPrompt: "You are a helpful writing assistant. Improve the clarity and grammar of the text while keeping the meaning.",
    userPrompt: "{{input}}",
    shortcutContext: "default-target",
  },
  {
    id: "formal",
    title: "Formal Tone",
    provider: "google",
    model: "gemini-1.5-flash-8b",
    systemPrompt: "Rewrite the following text in a formal, professional tone suitable for business communication.",
    userPrompt: "{{input}}",
    shortcutContext: "active-target",
  },
  {
    id: "summarize",
    title: "Summarize",
    provider: "google",
    model: "gemini-1.5-flash-8b",
    systemPrompt: "Summarize the following text concisely while retaining key information.",
    userPrompt: "{{input}}",
    shortcutContext: "active-target",
  },
]

export function ProfilesPanel() {
  const [profiles, setProfiles] = useState<TransformationProfile[]>(initialProfiles)
  const [defaultProfileId, setDefaultProfileId] = useState<string | null>("default")
  const [activeProfileId, setActiveProfileId] = useState("default")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<TransformationProfile | null>(null)

  const handleSetDefault = (id: string) => {
    setDefaultProfileId(defaultProfileId === id ? null : id)
  }

  const handleSetActive = (id: string) => {
    setActiveProfileId(id)
  }

  const handleEdit = (profile: TransformationProfile) => {
    setEditingId(profile.id)
    setEditForm({ ...profile })
  }

  const handleSaveEdit = () => {
    if (!editForm) return
    setProfiles((prev) => prev.map((p) => (p.id === editForm.id ? editForm : p)))
    setEditingId(null)
    setEditForm(null)
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setEditForm(null)
  }

  const handleDelete = (id: string) => {
    setProfiles((prev) => prev.filter((p) => p.id !== id))
    if (defaultProfileId === id) setDefaultProfileId(null)
    if (activeProfileId === id && profiles.length > 1) {
      setActiveProfileId(profiles.find((p) => p.id !== id)?.id ?? "")
    }
  }

  const handleAddProfile = () => {
    const newId = `profile-${Date.now()}`
    const newProfile: TransformationProfile = {
      id: newId,
      title: "New Profile",
      provider: "google",
      model: "gemini-1.5-flash-8b",
      systemPrompt: "",
      userPrompt: "{{input}}",
      shortcutContext: "active-target",
    }
    setProfiles((prev) => [...prev, newProfile])
    setEditingId(newId)
    setEditForm(newProfile)
  }

  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col gap-3 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="size-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Transformation Profiles</h3>
          </div>
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={handleAddProfile}>
            <Plus className="size-3" />
            Add
          </Button>
        </div>

        <p className="text-[11px] text-muted-foreground leading-relaxed">
          Profiles define how transcribed text is transformed by the LLM. Set one as default for quick access.
        </p>

        <Separator />

        <div className="space-y-2">
          {profiles.map((profile) => {
            const isDefault = defaultProfileId === profile.id
            const isActive = activeProfileId === profile.id
            const isEditing = editingId === profile.id

            if (isEditing && editForm) {
              return (
                <div key={profile.id} className="rounded-lg border border-primary/40 bg-card p-3 space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Title</Label>
                    <Input
                      value={editForm.title}
                      onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                      className="h-7 text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">Provider</Label>
                      <Select value={editForm.provider} disabled>
                        <SelectTrigger className="w-full h-7 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="google">Google</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">Model</Label>
                      <Select
                        value={editForm.model}
                        onValueChange={(v) => setEditForm({ ...editForm, model: v })}
                      >
                        <SelectTrigger className="w-full h-7 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="gemini-1.5-flash-8b">gemini-1.5-flash-8b</SelectItem>
                          <SelectItem value="gemini-1.5-flash">gemini-1.5-flash</SelectItem>
                          <SelectItem value="gemini-1.5-pro">gemini-1.5-pro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">System Prompt</Label>
                    <Textarea
                      value={editForm.systemPrompt}
                      onChange={(e) => setEditForm({ ...editForm, systemPrompt: e.target.value })}
                      className="text-xs min-h-[60px] resize-none"
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">
                      {'User Prompt (use {{input}} for transcript)'}
                    </Label>
                    <Input
                      value={editForm.userPrompt}
                      onChange={(e) => setEditForm({ ...editForm, userPrompt: e.target.value })}
                      className="h-7 text-xs font-mono"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={handleCancelEdit}>
                      <X className="size-3 mr-1" />
                      Cancel
                    </Button>
                    <Button size="sm" className="h-7 text-xs" onClick={handleSaveEdit}>
                      <Check className="size-3 mr-1" />
                      Save
                    </Button>
                  </div>
                </div>
              )
            }

            return (
              <div
                key={profile.id}
                className={cn(
                  "group rounded-lg border bg-card p-3 transition-all cursor-pointer",
                  isActive && "border-primary/40 bg-primary/5",
                  !isActive && "hover:border-border/80"
                )}
                onClick={() => handleSetActive(profile.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleSetActive(profile.id) }}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-sm font-medium text-foreground truncate">{profile.title}</span>
                    {isDefault && (
                      <Badge variant="secondary" className="text-[10px] h-4 gap-0.5 bg-primary/10 text-primary border-primary/20">
                        Default
                      </Badge>
                    )}

                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleSetDefault(profile.id) }}
                      className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-warning transition-colors"
                      aria-label={isDefault ? "Remove as default" : "Set as default"}
                    >
                      {isDefault ? <Star className="size-3.5 fill-warning text-warning" /> : <StarOff className="size-3.5" />}
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleEdit(profile) }}
                      className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                      aria-label="Edit profile"
                    >
                      <Pencil className="size-3.5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDelete(profile.id) }}
                      className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-destructive transition-colors"
                      aria-label="Delete profile"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </div>

                <div className="mt-1.5 flex items-center gap-2">
                  <span className="text-[10px] font-mono text-muted-foreground">{profile.provider}/{profile.model}</span>
                </div>
                {profile.systemPrompt && (
                  <p className="mt-1 text-[11px] text-muted-foreground line-clamp-1">{profile.systemPrompt}</p>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </ScrollArea>
  )
}
