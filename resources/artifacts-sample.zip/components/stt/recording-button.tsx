"use client"

import { cn } from "@/lib/utils"
import { Mic, Square, X } from "lucide-react"

type RecordingState = "idle" | "recording" | "processing"

interface RecordingButtonProps {
  state: RecordingState
  onToggle: () => void
  onCancel: () => void
  duration?: string
}

export function RecordingButton({ state, onToggle, onCancel, duration = "00:00" }: RecordingButtonProps) {
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        {state === "recording" && (
          <>
            <div className="absolute inset-0 rounded-full bg-recording/20 animate-ping" />
            <div className="absolute -inset-3 rounded-full bg-recording/10 animate-pulse" />
          </>
        )}
        <button
          onClick={onToggle}
          className={cn(
            "relative z-10 flex items-center justify-center rounded-full transition-all duration-200",
            "size-20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            state === "idle" && "bg-primary text-primary-foreground hover:bg-primary/90",
            state === "recording" && "bg-recording text-recording-foreground hover:bg-recording/90",
            state === "processing" && "bg-muted text-muted-foreground cursor-not-allowed opacity-60"
          )}
          disabled={state === "processing"}
          aria-label={state === "recording" ? "Stop recording" : "Start recording"}
        >
          {state === "recording" ? (
            <Square className="size-7 fill-current" />
          ) : (
            <Mic className="size-7" />
          )}
        </button>
      </div>

      <div className="flex flex-col items-center gap-1">
        {state === "recording" && (
          <>
            <span className="font-mono text-lg text-recording tabular-nums">{duration}</span>
            <button
              onClick={onCancel}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-destructive transition-colors"
              aria-label="Cancel recording"
            >
              <X className="size-3" />
              Cancel
            </button>
          </>
        )}
        {state === "idle" && (
          <span className="text-sm text-muted-foreground">
            Click to record
          </span>
        )}
        {state === "processing" && (
          <span className="text-sm text-muted-foreground animate-pulse">
            Processing...
          </span>
        )}
      </div>
    </div>
  )
}
