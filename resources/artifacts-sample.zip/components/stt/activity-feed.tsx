"use client"

import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle2, XCircle, Loader2, Copy, ClipboardPaste, Clock } from "lucide-react"

export type JobStatus =
  | "queued"
  | "transcribing"
  | "transforming"
  | "succeeded"
  | "transcription_failed"
  | "transformation_failed"
  | "output_failed_partial"

interface Job {
  id: string
  capturedAt: string
  status: JobStatus
  transcript?: string
  transformed?: string
  profileTitle?: string
  duration?: string
}

const statusConfig: Record<JobStatus, { label: string; icon: React.ComponentType<{ className?: string }>; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  queued: { label: "Queued", icon: Clock, variant: "secondary" },
  transcribing: { label: "Transcribing", icon: Loader2, variant: "outline" },
  transforming: { label: "Transforming", icon: Loader2, variant: "outline" },
  succeeded: { label: "Done", icon: CheckCircle2, variant: "default" },
  transcription_failed: { label: "STT Failed", icon: XCircle, variant: "destructive" },
  transformation_failed: { label: "LLM Failed", icon: XCircle, variant: "destructive" },
  output_failed_partial: { label: "Output Error", icon: XCircle, variant: "destructive" },
}

interface ActivityFeedProps {
  jobs: Job[]
  onCopy?: (jobId: string, type: "transcript" | "transformed") => void
  onPaste?: (jobId: string, type: "transcript" | "transformed") => void
}

export function ActivityFeed({ jobs, onCopy, onPaste }: ActivityFeedProps) {
  if (jobs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
        <Loader2 className="size-8 mb-3 opacity-20" />
        <p className="text-sm">No recent activity</p>
        <p className="text-xs mt-1">Start recording to see results here</p>
      </div>
    )
  }

  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col gap-2 p-1">
        {jobs.map((job) => {
          const config = statusConfig[job.status]
          const StatusIcon = config.icon
          const isProcessing = job.status === "transcribing" || job.status === "transforming"
          const isComplete = job.status === "succeeded"
          const isFailed = job.status.includes("failed")

          return (
            <div
              key={job.id}
              className={cn(
                "group rounded-lg border bg-card p-3 transition-colors",
                isFailed && "border-destructive/30",
                isComplete && "border-success/20"
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <StatusIcon
                    className={cn(
                      "size-4 shrink-0",
                      isProcessing && "animate-spin text-primary",
                      isComplete && "text-success",
                      isFailed && "text-destructive",
                      job.status === "queued" && "text-muted-foreground"
                    )}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Badge variant={config.variant} className="text-[10px] h-5">
                        {config.label}
                      </Badge>
                      {job.profileTitle && (
                        <span className="text-[10px] text-muted-foreground truncate">
                          {job.profileTitle}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {job.duration && (
                    <span className="text-[10px] font-mono text-muted-foreground">{job.duration}</span>
                  )}
                  <span className="text-[10px] text-muted-foreground">{job.capturedAt}</span>
                </div>
              </div>

              {(job.transcript || job.transformed) && (
                <div className="mt-2 space-y-2">
                  {job.transcript && (
                    <div className="group/text relative">
                      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 pr-14">
                        {job.transcript}
                      </p>
                      <div className="absolute top-0 right-0 flex gap-1 opacity-0 group-hover/text:opacity-100 transition-opacity">
                        <button
                          onClick={() => onCopy?.(job.id, "transcript")}
                          className="p-1 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                          aria-label="Copy transcript"
                        >
                          <Copy className="size-3" />
                        </button>
                        <button
                          onClick={() => onPaste?.(job.id, "transcript")}
                          className="p-1 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                          aria-label="Paste transcript"
                        >
                          <ClipboardPaste className="size-3" />
                        </button>
                      </div>
                    </div>
                  )}
                  {job.transformed && (
                    <div className="group/text relative rounded bg-secondary/50 p-2">
                      <p className="text-xs text-foreground leading-relaxed line-clamp-2 pr-14">
                        {job.transformed}
                      </p>
                      <div className="absolute top-1.5 right-1.5 flex gap-1 opacity-0 group-hover/text:opacity-100 transition-opacity">
                        <button
                          onClick={() => onCopy?.(job.id, "transformed")}
                          className="p-1 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                          aria-label="Copy transformed text"
                        >
                          <Copy className="size-3" />
                        </button>
                        <button
                          onClick={() => onPaste?.(job.id, "transformed")}
                          className="p-1 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                          aria-label="Paste transformed text"
                        >
                          <ClipboardPaste className="size-3" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </ScrollArea>
  )
}
