"use client"

import { cn } from "@/lib/utils"
import { Mic, Cpu, Wifi, WifiOff } from "lucide-react"

interface StatusBarProps {
  sttProvider: string
  sttModel: string
  llmProvider: string
  audioDevice: string
  isConnected: boolean
  activeProfile?: string
}

export function StatusBar({
  sttProvider,
  sttModel,
  llmProvider,
  audioDevice,
  isConnected,
  activeProfile,
}: StatusBarProps) {
  return (
    <footer className="flex items-center justify-between border-t bg-card/50 px-4 py-1.5">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <Mic className="size-3 text-muted-foreground" />
          <span className="text-[10px] font-mono text-muted-foreground">
            {sttProvider}/{sttModel}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Cpu className="size-3 text-muted-foreground" />
          <span className="text-[10px] font-mono text-muted-foreground">
            {llmProvider}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground">{audioDevice}</span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {activeProfile && (
          <span className="text-[10px] text-primary">{activeProfile}</span>
        )}
        <div className="flex items-center gap-1">
          {isConnected ? (
            <Wifi className={cn("size-3 text-success")} />
          ) : (
            <WifiOff className="size-3 text-destructive" />
          )}
          <span className="text-[10px] text-muted-foreground">
            {isConnected ? "Ready" : "Offline"}
          </span>
        </div>
      </div>
    </footer>
  )
}
