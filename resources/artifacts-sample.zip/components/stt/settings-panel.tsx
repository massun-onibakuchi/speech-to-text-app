"use client"

import { useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Kbd } from "@/components/ui/kbd"
import { Badge } from "@/components/ui/badge"
import { Mic, Cpu, Keyboard, Volume2, Clipboard, Eye, EyeOff } from "lucide-react"

export function SettingsPanel() {
  const [sttProvider, setSttProvider] = useState("groq")
  const [sttModel, setSttModel] = useState("whisper-large-v3-turbo")
  const [llmProvider] = useState("google")
  const [llmModel, setLlmModel] = useState("gemini-1.5-flash-8b")
  const [audioDevice, setAudioDevice] = useState("default")
  const [selectedTextSource, setSelectedTextSource] = useState<"transcript" | "transformed">("transformed")
  const [copyOutput, setCopyOutput] = useState(true)
  const [pasteOutput, setPasteOutput] = useState(false)
  const [showGroqKey, setShowGroqKey] = useState(false)
  const [showElevenLabsKey, setShowElevenLabsKey] = useState(false)
  const [showGoogleKey, setShowGoogleKey] = useState(false)

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Output -- shown first for immediate visibility */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Clipboard className="size-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Output</h3>
        </div>

        <div className="space-y-5">
          {/* Text Source -- exclusive selection */}
          <div className="space-y-2.5">
            <Label className="text-xs text-muted-foreground">Text Source</Label>
            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => setSelectedTextSource("transcript")}
                className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors ${
                  selectedTextSource === "transcript"
                    ? "border-primary/50 bg-primary/5"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <span
                  className={`flex size-4 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                    selectedTextSource === "transcript"
                      ? "border-primary"
                      : "border-muted-foreground/40"
                  }`}
                >
                  {selectedTextSource === "transcript" && (
                    <span className="size-2 rounded-full bg-primary" />
                  )}
                </span>
                <div className="flex flex-col">
                  <span className="text-xs font-medium text-foreground">Raw Dictation</span>
                  <span className="text-[10px] text-muted-foreground leading-snug">
                    Unprocessed transcript from the STT provider
                  </span>
                </div>
              </button>

              <button
                onClick={() => setSelectedTextSource("transformed")}
                className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors ${
                  selectedTextSource === "transformed"
                    ? "border-primary/50 bg-primary/5"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <span
                  className={`flex size-4 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                    selectedTextSource === "transformed"
                      ? "border-primary"
                      : "border-muted-foreground/40"
                  }`}
                >
                  {selectedTextSource === "transformed" && (
                    <span className="size-2 rounded-full bg-primary" />
                  )}
                </span>
                <div className="flex flex-col">
                  <span className="text-xs font-medium text-foreground">Transformed Text</span>
                  <span className="text-[10px] text-muted-foreground leading-snug">
                    Text refined by the active LLM profile
                  </span>
                </div>
              </button>
            </div>
            {selectedTextSource === "transformed" && (
              <p className="text-[10px] text-muted-foreground/70 leading-relaxed pl-0.5">
                Falls back to raw dictation if transformation is unavailable.
              </p>
            )}
          </div>

          {/* Destination -- multiselect */}
          <div className="space-y-2.5">
            <Label className="text-xs text-muted-foreground">Destination</Label>
            <div className="flex flex-col gap-1.5">
              <label
                className={`flex cursor-pointer items-center justify-between rounded-lg border px-3 py-2 transition-colors ${
                  copyOutput
                    ? "border-primary/50 bg-primary/5"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`flex size-4 shrink-0 items-center justify-center rounded transition-colors ${
                      copyOutput
                        ? "bg-primary"
                        : "border-2 border-muted-foreground/40"
                    }`}
                  >
                    {copyOutput && (
                      <svg className="size-2.5 text-primary-foreground" viewBox="0 0 12 12" fill="none">
                        <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </span>
                  <span className="text-xs font-medium text-foreground">Copy to clipboard</span>
                </div>
                <Switch checked={copyOutput} onCheckedChange={setCopyOutput} className="scale-90" />
              </label>

              <label
                className={`flex cursor-pointer items-center justify-between rounded-lg border px-3 py-2 transition-colors ${
                  pasteOutput
                    ? "border-primary/50 bg-primary/5"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`flex size-4 shrink-0 items-center justify-center rounded transition-colors ${
                      pasteOutput
                        ? "bg-primary"
                        : "border-2 border-muted-foreground/40"
                    }`}
                  >
                    {pasteOutput && (
                      <svg className="size-2.5 text-primary-foreground" viewBox="0 0 12 12" fill="none">
                        <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </span>
                  <span className="text-xs font-medium text-foreground">Paste at cursor</span>
                </div>
                <Switch checked={pasteOutput} onCheckedChange={setPasteOutput} className="scale-90" />
              </label>
            </div>
            {!copyOutput && !pasteOutput && (
              <p className="text-[10px] text-warning leading-relaxed pl-0.5">
                No destinations enabled -- captured text will only appear in the activity feed.
              </p>
            )}
          </div>
        </div>
      </section>

      <Separator />

      {/* STT Configuration */}
      <section>
          <div className="flex items-center gap-2 mb-4">
            <Mic className="size-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Speech-to-Text</h3>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Provider</Label>
              <Select value={sttProvider} onValueChange={setSttProvider}>
                <SelectTrigger className="w-full h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="groq">Groq</SelectItem>
                  <SelectItem value="elevenlabs">ElevenLabs</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Model</Label>
              <Select value={sttModel} onValueChange={setSttModel}>
                <SelectTrigger className="w-full h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sttProvider === "groq" ? (
                    <>
                      <SelectItem value="whisper-large-v3-turbo">whisper-large-v3-turbo</SelectItem>
                      <SelectItem value="whisper-large-v3">whisper-large-v3</SelectItem>
                      <SelectItem value="distil-whisper-large-v3-en">distil-whisper-large-v3-en</SelectItem>
                    </>
                  ) : (
                    <>
                      <SelectItem value="scribe_v1">Scribe v1</SelectItem>
                      <SelectItem value="scribe_v2">Scribe v2</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">
                {sttProvider === "groq" ? "Groq" : "ElevenLabs"} API Key
              </Label>
              <div className="flex gap-2">
                <Input
                  type={sttProvider === "groq" ? (showGroqKey ? "text" : "password") : (showElevenLabsKey ? "text" : "password")}
                  placeholder="sk-..."
                  className="h-8 text-xs font-mono flex-1"
                />
                <button
                  onClick={() => sttProvider === "groq" ? setShowGroqKey(!showGroqKey) : setShowElevenLabsKey(!showElevenLabsKey)}
                  className="p-1.5 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Toggle key visibility"
                >
                  {(sttProvider === "groq" ? showGroqKey : showElevenLabsKey) ? (
                    <EyeOff className="size-3.5" />
                  ) : (
                    <Eye className="size-3.5" />
                  )}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Base URL Override</Label>
              <Input
                type="text"
                placeholder="Leave empty for default"
                className="h-8 text-xs font-mono"
              />
            </div>
          </div>
        </section>

        <Separator />

        {/* LLM Configuration */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Cpu className="size-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">LLM Transformation</h3>
            <Badge variant="secondary" className="text-[10px] h-4">Google only in v1</Badge>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Provider</Label>
              <Select value={llmProvider} disabled>
                <SelectTrigger className="w-full h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="google">Google</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Model</Label>
              <Select value={llmModel} onValueChange={setLlmModel}>
                <SelectTrigger className="w-full h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gemini-1.5-flash-8b">gemini-1.5-flash-8b</SelectItem>
                  <SelectItem value="gemini-1.5-flash">gemini-1.5-flash</SelectItem>
                  <SelectItem value="gemini-1.5-pro">gemini-1.5-pro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Google API Key</Label>
              <div className="flex gap-2">
                <Input
                  type={showGoogleKey ? "text" : "password"}
                  placeholder="AIza..."
                  className="h-8 text-xs font-mono flex-1"
                />
                <button
                  onClick={() => setShowGoogleKey(!showGoogleKey)}
                  className="p-1.5 rounded bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Toggle key visibility"
                >
                  {showGoogleKey ? (
                    <EyeOff className="size-3.5" />
                  ) : (
                    <Eye className="size-3.5" />
                  )}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Base URL Override</Label>
              <Input
                type="text"
                placeholder="Leave empty for default"
                className="h-8 text-xs font-mono"
              />
            </div>
          </div>
        </section>

        <Separator />

        {/* Audio Device */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Volume2 className="size-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Audio Input</h3>
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Input Device</Label>
            <Select value={audioDevice} onValueChange={setAudioDevice}>
              <SelectTrigger className="w-full h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">System Default</SelectItem>
                <SelectItem value="builtin">MacBook Pro Microphone</SelectItem>
                <SelectItem value="external">USB Condenser Mic</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </section>

        <Separator />

        {/* Global Shortcuts */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Keyboard className="size-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Global Shortcuts</h3>
          </div>

          <div className="space-y-3">
            {[
              { label: "Toggle Recording", keys: ["Ctrl", "Shift", "Space"] },
              { label: "Cancel Recording", keys: ["Ctrl", "Shift", "X"] },
              { label: "Run Default Transform", keys: ["Ctrl", "Shift", "T"] },
              { label: "Pick & Run Transform", keys: ["Ctrl", "Shift", "P"] },
              { label: "Change Default Profile", keys: ["Ctrl", "Shift", "D"] },
              { label: "Transform Selection", keys: ["Ctrl", "Shift", "S"] },
            ].map((shortcut) => (
              <div key={shortcut.label} className="flex items-center justify-between">
                <span className="text-xs text-foreground">{shortcut.label}</span>
                <div className="flex items-center gap-1">
                  {shortcut.keys.map((key) => (
                    <Kbd key={key}>{key}</Kbd>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
    </div>
  )
}
