"use client"

import { useState, useEffect, useCallback } from "react"
import { cn } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RecordingButton } from "./recording-button"
import { ActivityFeed, type JobStatus } from "./activity-feed"
import { SettingsPanel } from "./settings-panel"
import { ProfilesPanel } from "./profiles-panel"
import { StatusBar } from "./status-bar"
import { Settings, Zap, Activity, AudioWaveform } from "lucide-react"

interface Job {
  id: string
  capturedAt: string
  status: JobStatus
  transcript?: string
  transformed?: string
  profileTitle?: string
  duration?: string
}

const demoJobs: Job[] = [
  {
    id: "job-1",
    capturedAt: "12:45 PM",
    status: "succeeded",
    transcript: "I need to schedule a meeting with the design team for next Tuesday to review the new dashboard mockups and discuss the timeline for the Q2 launch.",
    transformed: "Schedule a meeting with the design team for next Tuesday to review new dashboard mockups and discuss the Q2 launch timeline.",
    profileTitle: "Default Rewrite",
    duration: "8.2s",
  },
  {
    id: "job-2",
    capturedAt: "12:42 PM",
    status: "succeeded",
    transcript: "remind me to pick up groceries after work today we need milk eggs and bread",
    transformed: "Remind me to pick up groceries after work today. We need milk, eggs, and bread.",
    profileTitle: "Default Rewrite",
    duration: "5.1s",
  },
  {
    id: "job-3",
    capturedAt: "12:38 PM",
    status: "transformation_failed",
    transcript: "The quarterly report shows a fifteen percent increase in user engagement compared to last quarter with mobile traffic accounting for sixty percent of all visits.",
    profileTitle: "Formal Tone",
    duration: "12.4s",
  },
  {
    id: "job-4",
    capturedAt: "12:30 PM",
    status: "succeeded",
    transcript: "hey can you take a look at the pull request I just opened its for the authentication refactor",
    transformed: "Could you please review the pull request I just opened? It pertains to the authentication refactor.",
    profileTitle: "Formal Tone",
    duration: "6.8s",
  },
]

export function AppShell() {
  const [recordingState, setRecordingState] = useState<"idle" | "recording" | "processing">("idle")
  const [duration, setDuration] = useState("00:00")
  const [jobs, setJobs] = useState<Job[]>(demoJobs)
  const [sidebarTab, setSidebarTab] = useState("activity")

  // Simulate recording timer
  useEffect(() => {
    if (recordingState !== "recording") return
    let seconds = 0
    const interval = setInterval(() => {
      seconds++
      const mins = Math.floor(seconds / 60).toString().padStart(2, "0")
      const secs = (seconds % 60).toString().padStart(2, "0")
      setDuration(`${mins}:${secs}`)
    }, 1000)
    return () => clearInterval(interval)
  }, [recordingState])

  const handleToggle = useCallback(() => {
    if (recordingState === "idle") {
      setDuration("00:00")
      setRecordingState("recording")
    } else if (recordingState === "recording") {
      setRecordingState("processing")
      // Simulate processing
      setTimeout(() => {
        const newJob: Job = {
          id: `job-${Date.now()}`,
          capturedAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          status: "transcribing",
          duration: duration,
        }
        setJobs((prev) => [newJob, ...prev])
        setSidebarTab("activity")

        // Simulate transcription completion
        setTimeout(() => {
          setJobs((prev) =>
            prev.map((j) =>
              j.id === newJob.id
                ? {
                    ...j,
                    status: "transforming" as JobStatus,
                    transcript: "This is a sample transcription of the recorded audio segment.",
                  }
                : j
            )
          )

          // Simulate transformation completion
          setTimeout(() => {
            setJobs((prev) =>
              prev.map((j) =>
                j.id === newJob.id
                  ? {
                      ...j,
                      status: "succeeded" as JobStatus,
                      transformed: "This is a sample transcription of the recorded audio segment.",
                      profileTitle: "Default Rewrite",
                    }
                  : j
              )
            )
          }, 2000)
        }, 2000)

        setRecordingState("idle")
      }, 500)
    }
  }, [recordingState, duration])

  const handleCancel = useCallback(() => {
    setRecordingState("idle")
    setDuration("00:00")
  }, [])

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Title bar area */}
      <header className="flex items-center justify-between border-b px-4 py-2 bg-card/50">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center size-6 rounded-md bg-primary/10">
            <AudioWaveform className="size-3.5 text-primary" />
          </div>
          <h1 className="text-sm font-semibold text-foreground tracking-tight">Vocalize</h1>
        </div>
        <div className="flex items-center gap-1">
          <span className={cn(
            "size-2 rounded-full",
            recordingState === "recording" ? "bg-recording animate-pulse" : "bg-success"
          )} />
          <span className="text-[10px] text-muted-foreground">
            {recordingState === "idle" ? "Ready" : recordingState === "recording" ? "Recording" : "Processing"}
          </span>
        </div>
      </header>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left panel - Recording + Controls */}
        <div className="flex w-[320px] flex-col border-r">
          {/* Recording area */}
          <div className="flex flex-1 flex-col items-center justify-center border-b px-6 py-8">
            <RecordingButton
              state={recordingState}
              onToggle={handleToggle}
              onCancel={handleCancel}
              duration={duration}
            />


          </div>

          {/* Waveform visualization placeholder */}
          <div className="h-16 flex items-center justify-center gap-[3px] px-6 bg-card/30">
            {Array.from({ length: 32 }).map((_, i) => (
              <div
                key={i}
                className={cn(
                  "w-[3px] rounded-full transition-all duration-150",
                  recordingState === "recording"
                    ? "bg-recording/80"
                    : "bg-muted-foreground/20"
                )}
                style={{
                  height: recordingState === "recording"
                    ? `${Math.random() * 28 + 4}px`
                    : `${Math.sin(i * 0.3) * 6 + 8}px`,
                  animationDelay: `${i * 50}ms`,
                }}
              />
            ))}
          </div>
        </div>

        {/* Right panel - Tabbed content */}
        <div className="flex flex-1 flex-col">
          <Tabs value={sidebarTab} onValueChange={setSidebarTab} className="flex flex-1 flex-col">
            <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0 h-auto">
              <TabsTrigger
                value="activity"
                className="rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none"
              >
                <Activity className="size-3.5 mr-1.5" />
                Activity
              </TabsTrigger>
              <TabsTrigger
                value="profiles"
                className="rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none"
              >
                <Zap className="size-3.5 mr-1.5" />
                Profiles
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none"
              >
                <Settings className="size-3.5 mr-1.5" />
                Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="activity" className="flex-1 overflow-y-auto mt-0 p-3" style={{ minHeight: 0 }}>
              <ActivityFeed jobs={jobs} />
            </TabsContent>

            <TabsContent value="profiles" className="flex-1 overflow-y-auto mt-0" style={{ minHeight: 0 }}>
              <ProfilesPanel />
            </TabsContent>

            <TabsContent value="settings" className="flex-1 overflow-y-auto mt-0" style={{ minHeight: 0 }}>
              <SettingsPanel />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Status bar */}
      <StatusBar
        sttProvider="groq"
        sttModel="whisper-large-v3-turbo"
        llmProvider="google"
        audioDevice="System Default"
        isConnected={true}
        activeProfile="Default Rewrite"
      />
    </div>
  )
}
